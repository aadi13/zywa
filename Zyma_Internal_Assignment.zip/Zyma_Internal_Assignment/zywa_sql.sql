--1.Need how much amount we have processed each month commutative and every month.
--Insights Kept Transaction_status filter for 0 , Assuming 0 to be failed transaction status thus shoudn't count
SELECT DATEPART(month, transaction_timestamp) AS Month,
       SUM(transaction_amount) AS TotalProcessedAmount
FROM transactions
where transaction_status <> 0
GROUP BY DATEPART(month, transaction_timestamp)
ORDER BY Month ASC;

/*
Month   TotalProcessedAmount
1	18507866072
2	16727546703
3	9973669513
*/

--2.Design a SQL query to identify the top 5 most popular products or services based on transaction counts.
--Insights - Added filter for transaction_type as popularity of product/service correlates to intentional buying of that entity over times.

SELECT TOP 5
    merchant_type,
    COUNT(id) AS transaction_count
FROM
    transactions
Where 
    transaction_type = 'PURCHASE'
GROUP BY
    merchant_type
ORDER BY
    transaction_count DESC;

--3. Formulate a SQL query to visualize the daily revenue trend over time.
--Insights - Good pactice to take date/type as datatype for timestamp related columns in tables.
SELECT
    CONVERT(DATE, transaction_timestamp) AS transaction_date,
    SUM(billing_amount) AS daily_revenue
FROM
    transactions
GROUP BY
    CONVERT(DATE, transaction_timestamp)

--4.Average Transaction Amount by Product Category:
/*Insights TOP 3 Categories with highest Average Transaction amounts are for 
1. Petcare 
2. Books&Magazines 
3. Gaming */
SELECT
    merchant_type,
    AVG(transaction_amount) AS average_transaction_amount
FROM
    transactions
GROUP BY
    merchant_type
Order BY
    average_transaction_amount desc;

--5. Transaction Funnel Analysis:

SELECT
    COUNT(*) AS total_transactions,
    SUM(CASE WHEN transaction_status = '9102' THEN 1 ELSE 0 END) AS completed_transactions,
    SUM(CASE WHEN transaction_status = '1022' THEN 1 ELSE 0 END) AS pending_transactions,
    SUM(CASE WHEN transaction_status = '0' THEN 1 ELSE Null END) AS cancelled_transactions
FROM
    transactions;


--6 Monthly Retention Rate:

WITH UserCohorts AS (
    SELECT
        user_id,
        MIN(transaction_timestamp) AS cohort_start_date,
        merchant_type
    FROM
        transactions
    WHERE
        MONTH(transaction_timestamp) IN (1, 2, 3) -- Filter for Jan, Feb, March
    GROUP BY
        user_id, merchant_type
)
SELECT
    DATEADD(MONTH, DATEDIFF(MONTH, 0, cohort_start_date), 0) AS cohort_month,
    uc.merchant_type,
    COUNT(DISTINCT uc.user_id) AS cohort_size,
    COUNT(DISTINCT ua.user_id) AS retained_users,
    COUNT(DISTINCT ua.user_id) * 100.0 / COUNT(DISTINCT uc.user_id) AS retention_rate
FROM
    UserCohorts uc
JOIN
    transactions ua ON uc.user_id = ua.user_id AND uc.merchant_type = ua.merchant_type
GROUP BY
    DATEADD(MONTH, DATEDIFF(MONTH, 0, cohort_start_date), 0), uc.merchant_type
ORDER BY
    cohort_month, merchant_type;
















